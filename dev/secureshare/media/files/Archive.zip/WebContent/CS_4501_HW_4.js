/**
 * 
 */


function validate_form() {
    var form = document.forms['claim-form'];
    
    var claim = form['claim'].value;
    var reason = form['reason'].value;
    
    var invalid_claim = claim === null || claim === "";
    var invalid_reason = reason === null || reason === "";
    
    if (invalid_claim || invalid_reason) {
        alert("Oops! Looks like you forgot to enter something. Please try again. Make sure to enter a claim and reason.");
        return false;
    } else 
        return true;
}

function hide_instructions() {
    var instructions = document.getElementById('instructions-text');
    var btn_show = document.getElementById('btn_show_ins');
    var btn_hide = document.getElementById('btn_hide_ins');
    
    btn_show.disabled = null;
    btn_hide.disabled = 'true';
    
    instructions.style.display = 'none';
}

function show_instructions() {
    var instructions = document.getElementById('instructions-text');
    var btn_show = document.getElementById('btn_show_ins');
    var btn_hide = document.getElementById('btn_hide_ins');
    
    btn_show.disabled = 'true';
    btn_hide.disabled = null;
    instructions.style.display = 'block';
}
