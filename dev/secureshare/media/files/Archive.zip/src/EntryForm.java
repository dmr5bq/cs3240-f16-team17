
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EntryForm
 */

@WebServlet("/EntryForm")
public class EntryForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private int countAgree;
	private int countUnsure;
	private int countDisagree;

	private String currentClaim;
	private String currentReason;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EntryForm() {
		super();
		this.countAgree = 0;
		this.countDisagree = 0;
		this.countUnsure = 0;
		this.currentClaim = "";
		this.currentReason = "";
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String output = getFormRawHTML();
		out.println(output);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// sent through POST:
		// 	reason (String)
		//  claim  (String)
		//  vote (String)

		// check if the claim was just submitted
		if (request.getParameter("claim") != null && request.getParameter("reason") != null) {
			
			// save the claim and reason to the class
			String reason = request.getParameter("reason");
			String claim = request.getParameter("claim");

			this.currentClaim = claim;
			this.currentReason = reason;
			
		// check if a vote has been cast
		} else if ( request.getParameter("vote") != null ) {

			// set vote to the POSTed variable
			String vote = request.getParameter("vote");

			
			// update counts based on vote
			switch ( vote ) {
			
			case "agree":
				this.countAgree++;
				break;
				
			case "unsure":
				this.countUnsure++;
				break;
				
			case "disagree":
				this.countDisagree++;
				break;
				
			default:
				break;
				
			}
		}
		
		String output = getResponseRawHTML(this.currentClaim, this.currentReason, this.countAgree, this.countDisagree, this.countUnsure);


		PrintWriter out = response.getWriter();
		out.println(output);

	}

	private String getHeadHTML() {
		
		return 
				"<!DOCTYPE html>" + '\n' + "<html>" + '\n' +
				"<head>"+ '\n' +
				"<meta charset='utf-8'>"+ '\n' +
				"<link rel='stylesheet' href='master.css'>" + '\n'+
				"<script src=\"CS_4501_HW_4.js\"></script>"+ '\n' +
				"<title>Homework 4 - CS 4501</title>"+ '\n' +
				"</head>"+ '\n';
	}

	private String getResponseRawHTML(String claim, String reason, int ag, int dis, int uns) {
		return  getHeadHTML() +
				"<div class='panel'>"+ '\n'+
				"<div class=\"panel-inner\">" + '\n'+
				"<h4>Your Claim:</h4>" + '\n'+
				"<p>" + claim + "</p>" + '\n'+ "<br>"+ '\n' +
				"<h4>Your Reason:</h4>" + '\n'+
				"<p>" + reason + "</p>" + '\n'+
				"</div>" + '\n'+
				getResponseButtonsHTML(ag, dis, uns) +
				"</div>" + '\n';
	}

	private String getResponseButtonsHTML(int a, int d, int u) {
		return  "<form class='panel-inner' action=\"EntryForm\" method='post'>"+ '\n' +
				"<button type='submit' name='vote' value='agree'>Agree "+ a +"</button>"+ '\n' + 
				"<button type='submit' name='vote' value='disagree'>Disagree " + d + "</button>"+ '\n' + 
				"<button type='submit' name='vote' value='unsure'>Unsure " + u + "</button>"+ '\n' +
				"</form>";
	}


	private String getFormRawHTML() {

		return  getHeadHTML() +
				"<div class='panel'>"+ '\n' + 
				"<h2 class='panel-title'>Welcome</h2>" + '\n'+
				"<h3 class='panel-title'>It's good to see you again</h3>" + '\n'+
				"<form name='claim-form' class='panel-inner' method='post' action='EntryForm'>" + '\n'+ 
				"<table>"+ '\n' +
				"<tr>"+ '\n' + 
				"<td class='outline-dotted'>"+ '\n' + 
				getInstructionsHTML() +
				"</td>" + '\n'+     
				"</tr>"+ '\n' +
				"<tr>" + '\n'+
				"<td>" + '\n'+
				"<br><br><hr><br>" + '\n'+
				"<p class='form-label'>What do you have to say?</p></td>" + '\n'+
				"</tr>" + '\n'+
				"<tr>" + '\n' + 
				"<td><textarea cols=\"100\" rows='10' placeholder=\"What\'s on your mind?\" name='claim' required></textarea></td>"+ '\n' +
				"</tr>" + '\n'+
				"<tr>"+ '\n' +
				"<td><p class='form-label'>Tell your friends why.</p></td>" + '\n'+
				"</tr>" + '\n'+
				"<tr>" + '\n'+
				"<td><textarea cols=\"100\" rows='20' placeholder=\"What's on your mind?\" name='reason' required></textarea></td>"+ '\n' +
				"</tr>" + '\n'+ 
				"<tr>" + '\n'+
				"<td>" + '\n'+
				"<button type='submit' onsubmit=\"validate_form()\">Submit</button>"+ '\n' +
				"</td>" + '\n'+
				"</tr>" + '\n'+ 
				"</table></form></div>";
	}
	
	private String getInstructionsHTML() {
		return "<p class='instructions-title'>Instructions</p>"+ '\n' + 
				"<button id='btn_hide_ins' type=\"button\" onclick=\"hide_instructions()\">Hide Instructions</button>" + '\n'+ 
				"<button id='btn_show_ins' type=\"button\" onclick=\"show_instructions()\" disabled='true'>Show Instructions</button>" + '\n'+
				"<p class='instructions' id='instructions-text'>In the text boxes below, please enter a claim or assertion that you would like /"
				+ "to make in the first box. In the second box, tell your friends why you believe you're right, and then when it's all/"
				+ " ready, hit Submit. Your friends will then be able to see your post, and vote whether they think you're right or not.</p>" + '\n';
	}
}
